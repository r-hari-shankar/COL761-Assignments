python3 ./Q1/q1.py $1 
python3 ./Q1/plotter.py $2 
