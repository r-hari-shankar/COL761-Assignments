import matplotlib.pyplot as plt
import os
import sys
graph_name= sys.argv[1]
file1 = open("gaston.txt", "r")
file2 = open("fsg.txt","r")
file3 = open("gspan.txt","r")
xvalues = [5.0,10.0,25.0,50.0,95.0]
y1values = [] 
y2values = []
y3values = []

for line in file1:
    a = line.split()
    for i in range(5):
        y1values.append(float(a[i]))
for line in file2:
    a = line.split()
    for i in range(5):
        y2values.append(float(a[i]))
for line in file3:
    a = line.split()
    for i in range(5):
        y3values.append(float(a[i]))

plt.title('Plot of gspan,fsg,gaston')
plt.plot(xvalues, y1values, label = "gaston")
plt.plot(xvalues, y2values, label = "fsg")
plt.plot(xvalues, y3values, label = "gspan")
plt.xlabel("Frequency Thresholds (in %)")
plt.ylabel("Running time (in secs)")
plt.legend()
plt.savefig(sys.argv[1]+".png")
plt.show()

