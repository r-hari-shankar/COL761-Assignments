#python3 q1.py 167.txt gspan
import os
import sys
import time
import matplotlib.pyplot as plt
import numpy as np

file_name = sys.argv[1]
base_name = file_name.replace('.txt','')
tools=['gspan','gaston','fsg']
for tool in tools:
	tool_name = tool
	minsup = [5.0,10.0,25.0,50.0,95.0]
	output_name = base_name + '_' + tool_name + '.txt'
	file_obj = open(file_name,'r')
	file_lines = file_obj.readlines()
	file_obj.close()

	outfile = open(output_name,'w')
	
	if tool_name=='fsg':
		flag,cnt = 1,0
		for line in file_lines:
			if line[0]=='#':
				outfile.write('t\n')
				flag,cnt = 1,0
			elif line.replace('\n','').isdigit()==True:
				flag = (1-flag)
				cnt = 0
			elif flag==0:
				lvtx = 'v' + ' ' + str(cnt) + ' ' + line.replace('\n','') + '\n'
				outfile.write(lvtx)
				cnt = cnt + 1
			elif flag==1:
				if(line.replace('\n','')!=''):
					line_edge = 'u' + ' ' + line.replace('\n','') + '\n'
					outfile.write(line_edge)
	elif tool_name=='gspan' or tool_name=='gaston':
		flag = 1
		cnt = 0
		cnt_global = 0
		d_map = dict()
		vc = 0
		for line in file_lines:
			if line[0]=='#':
				outfile.write('t # ' + str(cnt_global) + '\n')
				flag,cnt = 1,0
				cnt_global = cnt_global+1
			elif line.replace('\n','').isdigit()==True:
				flag = (1-flag)
				cnt = 0
			elif flag==0:
				word = line.replace('\n','')
				if word not in d_map:
					d_map[word] = vc
					vc = vc+1
				
				lvtx = 'v' + ' ' + str(cnt) + ' ' + str(d_map[word]) + '\n'
				cnt = cnt + 1
				outfile.write(lvtx)
			elif flag==1:
				if(line.replace('\n','')!=''):
					line_edge = 'e' + ' ' + line.replace('\n','') + '\n'
					outfile.write(line_edge)
	outfile.close()

	filename = base_name + '_' + tool_name + '.txt'
	graph = 64110
	output = []

	for freq in minsup:
		if tool_name=='gspan':
			cmd = './gSpan6/gSpan -f ' + filename + ' -s ' + str(freq/100.0) + ' -o'
		elif tool_name=='gaston':
			cmd = './gaston-1.1/gaston ' + str((freq * graph)/100.0) + ' ' + filename
		elif tool_name=='fsg':
			cmd = './pafi-1.0.1/Linux/fsg -s ' + str(freq) + ' ' + filename
		else:
			break
		# Running time of method
		begin = time.time()
		os.system(cmd)
		end = time.time()
		print(freq, end-begin)
		output.append(end-begin)
	olf=tool_name+'.txt'
	olw=open(olf,'w')
	for i in range(len(output)):
		tt=str(output[i])+'\t'
		olw.write(tt)
	olw.close()