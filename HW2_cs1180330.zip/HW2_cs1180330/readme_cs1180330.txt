Library dependencies:
Q1: matplotlib, numpy

Q2: sklearn, matplotlib, numpy

