import mtree
import numpy as np
import time
import random
import math
from sklearn.decomposition import PCA
from sklearn.neighbors import KDTree
import matplotlib.pyplot as plt
from queue import PriorityQueue
import sys

X = np.loadtxt(sys.argv[1], unpack=True)
X = np.transpose(X)

def doPCA(X,n):
	pca = PCA(n_components=n)
	fitz = pca.fit_transform(X)
	return fitz

dims = [2,4,10,20]
pca_X = [doPCA(X,n) for n in dims]

points = []
while len(points)<100:
	x = random.randint(0,len(X)-1)
	if x not in points:
		points.append(x)

gbl_query_points = []
for x in pca_X:
	query_points = []
	for i in points:
		query_points.append(x[i])
	query_points = np.array(query_points)
	gbl_query_points.append(query_points)

def dxy(x, y):
	res = 0
	for i in range(len(x)):
		res += (x[i]-y[i])**2
	return math.sqrt(res)

def knn_sequential(x, k, point):
	q = PriorityQueue()
	for y in x:
		d = dxy(point,y)
		if (q.qsize()<k):
			q.put(-1*d)
		else:
			top = q.get()
			if (abs(top)>abs(d)):
				q.put(-1*d)
			else:
				q.put(top)
	res = []
	while not q.empty():
		next_pt = q.get()
		res.append(next_pt)
	return res[::-1]

time_mtree = []
std_mtree = []
for i,x in enumerate(pca_X):
	mtreez = mtree.MTree(dxy,max_node_size=2000000)
	mtreez.add_all(x.tolist())
	lcl_time = []
	for point in gbl_query_points[i]:
		start = time.time()
		list(mtreez.search(point,5))
		end = time.time()
		lcl_time.append(end-start)
	lcl_time = np.array(lcl_time)
	time_mtree.append(np.mean(lcl_time))
	std_mtree.append(np.std(lcl_time))

time_kdtree = []
std_kdtree = []
for i,x in enumerate(pca_X):
	kd_tree = KDTree(x)
	lcl_time = []
	for point in gbl_query_points[i]:
		start = time.time()
		dist, index = kd_tree.query([point],k=5)
		end = time.time()
		lcl_time.append(end-start)
	lcl_time = np.array(lcl_time)
	time_kdtree.append(np.mean(lcl_time))
	std_kdtree.append(np.std(lcl_time))

time_seq = []
std_seq = []
for i,x in enumerate(pca_X):
	lcl_time = []
	for point in gbl_query_points[i]:
		start = time.time()
		knn_sequential(x,5,point)
		end = time.time()
		lcl_time.append(end-start)
	lcl_time = np.array(lcl_time)
	time_seq.append(np.mean(lcl_time))
	std_seq.append(np.std(lcl_time))

X_plot = np.array([0,1,2,3])
X_plotticks = ['2','4','10','20']
width = 0.25
fig, ax = plt.subplots()
ax.bar(X_plot-width, time_kdtree, width, yerr=std_kdtree, ecolor='black', label='KDTree')
ax.bar(X_plot, time_mtree, width, yerr=std_mtree, ecolor='black', label='MTree')
ax.bar(X_plot+width, time_seq, width, yerr=std_seq, ecolor='black', label='Sequential')

ax.set_title('Query Time vs Dimensions')
ax.set_ylabel('Avg Query Time (in seconds)')
ax.set_xlabel('Dimension')
ax.set_xticks(X_plot)
ax.set_xticklabels(X_plotticks)
plt.tight_layout()
ax.legend()
plt.savefig(sys.argv[2]+".png")
plt.show()