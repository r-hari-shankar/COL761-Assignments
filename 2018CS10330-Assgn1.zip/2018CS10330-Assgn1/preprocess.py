import pandas as pd 
import numpy as np

f = open("paths_finished.tsv", "r")
fout = open("paths_finished.dat", "w") 

lines = f.readlines()
lines = lines[16:]
arr = []
for x in lines:
    y = x.split('\t')
    z = y[3].split(';')
    stack = []
    for i in range(len(z)):
        if(z[i]=="<"):
            stack.pop()
            z[i] = stack[len(stack)-1]
        else:
            stack.append(z[i])
    newz = ""
    for a in z:
        if(newz==""):
            newz = newz+a
        else:
            newz = newz+" "+a
    arr.append(newz)

for x in arr:
    fout.write(x)
    fout.write('\n')

f.close()
fout.close()