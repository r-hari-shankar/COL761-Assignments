import re
import sys
import math

class pytprefixspan:
    def __init__(self, pattern, minsup=2, len=1):
        self.seq = pattern
        self.minsup = minsup
        self.len = len
        self.out = {}
    def output(self, str):
        print(str)
    def ext(self, minsup, seq):
        h = dict()
        for i, item in enumerate(seq):
            dist = re.split(' +', item)
            for j in dist:
                if j in h:
                    h[j] += 1
                else:
                    h[j] = 1
        for k in list(h):
            if h[k] < minsup:
                del h[k]
        return h
    def fact(n):
	    if n == 1:
	       return n
	    else:
	       return n*fact(n-1)
    def project(self, seq, b):
        h = []
        for i, item in enumerate(seq):
            list = re.split(' +', item)
            if b in list:
                dist = list[list.index(b)+1:]
                if len(dist) > 0:
                    h.append(" ".join(dist))
        return h

    def _prefixspan(self, prefix, seq):
        minsup = self.minsup;
        pattern = self.ext(minsup, seq)
        for key, value in pattern.items():
            p = prefix + " " + key

            count = len(re.findall(' +', p))
            if count >= self.len:
                p = p.strip()
                self.out.update({p:value})
            j = self.project(seq, key)
            self._prefixspan(p, j);
        return
    def run(self):
        self._prefixspan("", self.seq)
        return
sample_input = ['a b c d e',
'b b b d e',
'c b c c a',
'b b b c c']

f = open(sys.argv[1], "r")
lines = f.readlines()
X = float(sys.argv[2])
T = len(lines)
support = (X*T)/100
out= pytprefixspan(lines,minsup=support)
# out= pytprefixspan(sample_input)
out.run()
# print(vars(out))
fout = open(sys.argv[3]+".txt", "w")
for x,y in vars(out)["out"].items():
    z = x.split()
    z.sort()
    z = " ".join(z)
    fout.write(z+"\n")

