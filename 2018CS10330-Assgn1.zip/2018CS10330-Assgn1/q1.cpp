#include <vector>
#include <algorithm>
#include <string>
#include <unordered_map>
#include <iostream>
#include <fstream>
#include <sstream>

using namespace std;

long T = 0, max_len = 0;
float x;

bool isSubsequence(vector<int> a, vector<int> b){
    int j = 0;
    for(int i=0;i<b.size();i++){
        if(b[i]>a[j])
            break;
        else if(b[i]==a[j])
            j++;
    }
    if(j==a.size())
        return true;
    return false;
}

bool should_prune(vector<vector<int>> &F, vector<int> &c) {
    for(int i=0;i<c.size()-2;i++){
        bool found = false;
        for(int j=0;j<F.size();j++){
            int ind = 0;
            int k = 0;
            while(k<c.size()) {
                if(k==i){
                    k++;
                    continue;
                }
                if(c[k++]!=F[j][ind++])
                    break;
            }
            if(k == c.size()) {
				found = true;
				break;
			}
        }
        if(!found) {
            return true;
        }
	}
	return false;
}

void candidate_gen(vector<vector<int>> &F, vector<vector<int>> &C) {
    int flen = F.size();
    for(int i=0;i<flen;i++){
        for(int j=i+1;j<flen;j++){
            vector<int> f1 = F[i];
            vector<int> f2 = F[j];
            int ind = 0;
            while(f1[ind]==f2[ind] && ind<f1.size()-1) ind++;
            if(ind==f1.size()-1 && f1.back()!=f2.back()){
                int n = f1.size();
                vector<int> c(n+1);
                for(int i=0;i<n-1;i++){
                    c[i] = f1[i];
                }
                if(f1.back()<f2.back()){
                    c[n-1] = f1.back();
                    c[n] = f2.back();   
                }
                else{
                    c[n-1] = f2.back();
                    c[n] = f1.back();    
                }
                if(!should_prune(F, c)) {
                    C.push_back(c);
                }
            }   
        }
    }
}

void generateC1(vector<vector<int>> &C1, vector<vector<int>> &F1, char *argv[]) {
	string line;
	ifstream fin;
	fin.open(argv[1], ifstream::in);
	unordered_map<int, int> count;
	while (getline(fin, line)) {
        vector<int> set;
        stringstream lineStream(line);
        int value;
        while(lineStream >> value) {
            set.push_back(value);
        }
        for(int i = 0; i < set.size(); i++) {
			if(count.find(set[i]) == count.end()) {
				count[set[i]] = 1;
                vector<int> temp = {set[i]};
                C1.push_back(temp);
			} else {
				count[set[i]]++;
			}
		}
        T++;
        max_len = max(max_len,(long) set.size());
    }
    fin.close();

	for(int i = 0; i < C1.size(); i++) {
		if(count[C1[i][0]] * 100 >= x * T) {
			F1.push_back(C1[i]);
		}
	}
}

int main(int argc, char *argv[]) {
	string line;
	ifstream fin;
	x = atof(argv[2]);
	vector<vector<int>> C1;
	vector<vector<int>> F1;
    generateC1(C1,F1,argv);
	vector<vector<vector<int>>> Fsets;
	vector<vector<vector<int>>> Csets;
	Csets.push_back(C1);
	Fsets.push_back(F1);

	while(Fsets.back().size() != 0 && Fsets.size() < max_len) {
	    vector<vector<int>> c;
		candidate_gen(Fsets.back(), c);
		Csets.push_back(c);
		vector<int> count(c.size(), 0);
		fin.open(argv[1], ifstream::in);
        while (getline(fin, line)) {
            vector<int> set;
            stringstream lineStream(line);
            int value;
            while(lineStream >> value)
            {
                set.push_back(value);
            }
            for(int i = 0; i < c.size(); i++) {
				if(set.size() >= c[i].size() && includes(set.begin(), set.end(), c[i].begin(), c[i].end())) {
					count[i]++;
				}
		   }
        }
		fin.close();

		Fsets.push_back(vector<vector<int>>());
		for(int i = 0; i < count.size(); i++) {
			if(count[i] * 100 >= x * T) {
				Fsets.back().push_back(c[i]);
			}
		}
	}
    if(argc<4) return 0;
	ofstream writeout;
	writeout.open(argv[3]);
	for(int i=0;i<Fsets.size(); i++) {
		for(int j=0;j<Fsets[i].size(); j++) {
            vector<string> temp(Fsets[i][j].size());
			for(int k=0;k<Fsets[i][j].size(); k++) {
                temp[k] = to_string(Fsets[i][j][k]);
			}
            sort(temp.begin(),temp.end());
			for(int k=0;k<Fsets[i][j].size(); k++) {
				writeout << stoi(temp[k]) << " ";
            }
            writeout << endl;
		}
	}
	writeout.close();

	return 0;
}