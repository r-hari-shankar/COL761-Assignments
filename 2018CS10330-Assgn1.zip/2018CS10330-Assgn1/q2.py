import subprocess
import time
import numpy as np
from matplotlib import pyplot as plt 
import sys

def plot(support_threshold, execution_time):
	x1 = [1.5,5.5,9.5,13.5,17.5]
	x2 = [2,6,10,14,18]
	x3 = [2.5,6.5,10.5,14.5,18.5]
	plt.xticks(x2, support_threshold)
	plt.xlabel('Support Threshold ---->')
	plt.ylabel('Execution Time (in sec) ---->')
	plt.title('Apriori vs Fpgrowth')
	plt.bar(x1, execution_time[0],width=1, label="Apriori")
	plt.bar(x3, execution_time[1],width=1, label="Fpgrowth")
	plt.legend()
	plt.savefig("test.png")

support_threshold = [5,10,25,50,90]

apriori_exe = "./apriori"
fpgrowth_exe = "./fpgrowth/fpgrowth/src/fpgrowth"
input_file = sys.argv[1]

#Computing Time for Apriori 
execution_time_apriori = []
for threshold in support_threshold:
	start_time = time.time()
	subprocess.run([apriori_exe,input_file,str(threshold)],timeout=3600)
	finish_time = time.time()
	execution_time_apriori.append(finish_time-start_time);

# Computing Time for Fprowth
execution_time_fpgrowth = []
for threshold in support_threshold:
	start_time = time.time()
	subprocess.run([fpgrowth_exe,"-s"+str(threshold),input_file],timeout=3600)
	finish_time = time.time()
	execution_time_fpgrowth.append(finish_time-start_time);

plot(support_threshold, [execution_time_apriori, execution_time_fpgrowth])
