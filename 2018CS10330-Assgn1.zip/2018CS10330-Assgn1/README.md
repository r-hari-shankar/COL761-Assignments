README for Assignment 1
COL761 (Data Mining)

Team Members -
Amit Shekhar (2018CS10738)
Diwakar Prajapati (2018CS10330)
R Hari Shankar (2019CS10386)

Files:

Bash Scripts-
1. install.sh
2. compile.sh
3. 2018CS10330.sh
(as per specifications)

Code-
1. q1.cpp
Contains the code for apriori algorithm
Each line of output ends in a space followed by newline character.
Last line of the output file is an empty line.
2. q2.py
Contains the code that plots the running times of fp growth and apriori algorithm by executing them
3. q3.py
Contains the code for prefix span algorithm
4. preprocess.py
Preprocess the data contained in file paths_finished.tsv and writes onto paths_finished.dat
Items in the preprocessed file are space separated and the last item in each line is followed by a newline character
Each line of output ends in a newline character (No space).
Last line of the output file is an empty line.


Explanation Q2:

Apriori generates the candidate set of size k from the frequent item set of size k-1.
Fpgrowth has a tree approach of the frequent item set.
After generation of candidate sets apriori prune it to find the frequent item set using another parse through the entire data set, while no such approach is found in fpgrowth i.e. fpgrowth stores the frequencies in the tree fashion.

Apriori is much faster than FPgrowth because of various factors:
1. Apriori access the entire data stored on the disk multiple times , while Fpgrowth accesses only once.
2. Apriori prunes the candidate set at each iteration.

Apriori search the frequent pattern in Breadth-First-Search fashion, while FPgrowth uses Depth-First-Search fashion.

Assumption:
We are not storing the entire data set in both the algorithms, but in case of fpgrowth we build the tree and store it in memory, hence its an assumption that the tree generated in fpgrowth is of such size which can be stored in memory, if not then the Fpgrowth fails.

Statistics:
With decrease in threshold the apriori alogrithm take more and more time (roughly exponential growth in time).
So with threshold of more than 50-60% the time difference between the two is insignificant.
But for low threshold for example 5%, Fpgrowth takes around 1 hr while Apriori take more than 10-12 hrs.

Thus Fpgrowth is much efficient than Apriori.
